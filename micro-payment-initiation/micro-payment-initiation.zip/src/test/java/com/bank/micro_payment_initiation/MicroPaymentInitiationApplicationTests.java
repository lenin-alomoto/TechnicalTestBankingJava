package com.bank.micro_payment_initiation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroPaymentInitiationApplicationTests {

	@Test
	void contextLoads() {
	}

}
