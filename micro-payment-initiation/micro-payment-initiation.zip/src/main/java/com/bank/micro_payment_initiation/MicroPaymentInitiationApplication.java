package com.bank.micro_payment_initiation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroPaymentInitiationApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroPaymentInitiationApplication.class, args);
	}

}
